from trajplot.autofuns import icheck

icheck( 
	path_raw_trajectories = 'raw_trajectories/' ,  
	path_movie = 'movie.tif' ,
	coord_col = ( 1 , 2 ) , comment_char = "#" , r = 5) 
