from trajplot.autofuns import icheck

# default cmap ( 'gray' )
icheck( 
	path_raw_trajectories = 'raw_trajectories/' ,  
	path_movie = 'movie.tif' ,
	coord_col = ( 1 , 2 ) , comment_char = "#" , r = 5) 

## viridis cmap
#icheck( 
#	path_raw_trajectories = 'raw_trajectories/' ,  
#	path_movie = 'movie.tif' ,
#	coord_col = ( 1 , 2 ) , comment_char = "#" , r = 5 , cmap = 'viridis' ) 
