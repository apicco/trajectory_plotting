from trajplot.autofuns import icheck
from trajalign.average import load_directory

path_trajectories = 'raw_trajectories/'

tts = load_directory(
		path = path_trajectories ,
		pattern = '.txt$' ,
		comment_char = '#' , 
		dt = 1, 
		t_unit = 's' , 
		coord_unit = 'pxl' , 
		frames = 0 , 
		coord = ( 1 , 2 ) ) 

icheck( 
	tts ,
	path_movie = 'movie.tif' ,
	path_output = 'demo' ,
	r = 10 , 
	marker = '+' , 	
	cmap = 'viridis' , offset = ( 0 , 0 ) , buffer_frames = 3 ) 

# default cmap = 'gray'
